// src/components/Payment.jsx
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

export default function Payment() {
  const { packageId, accommodationId } = useParams();
  const [total, setTotal]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => {
    const fetchTotal = async () => {
      try {
        const params = new URLSearchParams({ package_id: packageId });
        if (accommodationId) params.append("accommodation_id", accommodationId);

        const res = await fetch(`/api/prices?${params.toString()}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const { total_price } = await res.json();
        setTotal(total_price);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchTotal();
  }, [packageId, accommodationId]);

  if (loading) return <p>Loading total price…</p>;
  if (error)   return <p className="text-red-600">Error: {error}</p>;

  return (
    <div className="payment-container">
      <h2>Review &amp; Pay</h2>
      <p>
        Package ID: <strong>{packageId}</strong><br />
        {accommodationId && (
          <>Accommodation ID: <strong>{accommodationId}</strong><br /></>
        )}
      </p>
      <h3>Total: ${total.toFixed(2)}</h3>
      <button
        className="btn btn-primary"
        onClick={() => alert("Redirect to payment gateway")}
      >
        Proceed to Payment
      </button>
    </div>
  );
}
