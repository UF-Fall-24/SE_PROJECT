import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import App from "../App";
import userEvent from "@testing-library/user-event";

describe("Navigation Tests", () => {
  test("navigates from Home to About Us page", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <App />
      </MemoryRouter>
    );

    // Click "About Us" link
    const aboutLink = screen.getByRole("link", { name: /about us/i });
    expect(aboutLink).toBeInTheDocument();
    await userEvent.click(aboutLink);

    // Verify navigation to About Us page
    expect(await screen.findByText(/about us/i)).toBeInTheDocument();
  });

  test("navigates from Home to Contact Us page", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <App />
      </MemoryRouter>
    );

    // Click "Contact Us" link
    const contactLink = screen.getByRole("link", { name: /contact us/i });
    expect(contactLink).toBeInTheDocument();
    await userEvent.click(contactLink);

    // Verify navigation to Contact Us page
    expect(await screen.findByText(/contact us/i)).toBeInTheDocument();
  });

  test("navigates to Register page from Home", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <App />
      </MemoryRouter>
    );

    // Click "Register" link
    const registerLink = screen.getByRole("link", { name: /register/i });
    expect(registerLink).toBeInTheDocument();
    await userEvent.click(registerLink);

    // Verify navigation to Register page
    expect(await screen.findByText(/register/i)).toBeInTheDocument();
  });

  test("navigates to Login page from Home", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <App />
      </MemoryRouter>
    );

    // Click "Login" link
    const loginLink = screen.getByRole("link", { name: /login/i });
    expect(loginLink).toBeInTheDocument();
    await userEvent.click(loginLink);

    // Verify navigation to Login page
    expect(await screen.findByText(/login/i)).toBeInTheDocument();
  });
});
