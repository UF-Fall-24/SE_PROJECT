// src/components/About.js
import React from 'react';

const About = () => {
    return (
        <div>
            <h2>About Us</h2>
            <p>We are a leading travel booking platform dedicated to providing the best travel experiences.</p>
        </div>
    );
};

export default About;